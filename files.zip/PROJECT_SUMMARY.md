# Lending Decision API (LDA) - Project Summary

## Overview
Complete Quarkus-based microservice for credit decision processing, following the same architectural patterns as the Rate Change Service (RCS).

## Project Structure

```
lending-decision-api/
├── app/                                    # Main application module
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/nz/co/westpac/lending/decision/
│   │   │   │   ├── config/
│   │   │   │   │   └── LendingDecisionConfig.java
│   │   │   │   ├── exception/
│   │   │   │   │   ├── DecisionNotFoundException.java
│   │   │   │   │   ├── ExceptionHandler.java
│   │   │   │   │   ├── IneligibleApplicantException.java
│   │   │   │   │   └── InvalidDecisionRequestException.java
│   │   │   │   ├── impl/
│   │   │   │   │   ├── AuthenticationRequestFilter.java
│   │   │   │   │   └── DecisionsV1ServiceImpl.java
│   │   │   │   ├── service/
│   │   │   │   │   └── CreditDecisionService.java
│   │   │   │   └── util/
│   │   │   │       └── CorrelationIdContext.java
│   │   │   └── resources/
│   │   │       └── application.yaml
│   │   ├── test/java/nz/co/westpac/lending/decision/
│   │   │   ├── impl/
│   │   │   │   └── DecisionsV1ServiceImplTest.java
│   │   │   └── service/
│   │   │       └── CreditDecisionServiceTest.java
│   │   └── integrationTest/java/nz/co/westpac/lending/decision/
│   │       └── DecisionsApiIntegrationTest.java
│   └── build.gradle
├── lending-decision-api/                   # API module (OpenAPI generated)
│   ├── src/main/resources/openapi/
│   │   └── lending-decision-api.yaml
│   └── build.gradle
├── gradle/wrapper/
│   └── gradle-wrapper.properties
├── build.gradle                            # Root build configuration
├── settings.gradle                         # Multi-module setup
├── gradle.properties                       # Gradle properties
├── .gitignore
└── README.md

## Key Features

### 1. Credit Decision API
- **POST /decisions/v1**: Create new credit decision
- **GET /decisions/v1/{decisionId}**: Retrieve decision by ID

### 2. Automated Decision Engine
- Credit score evaluation
- Loan-to-Value Ratio (LVR) calculation
- Employment status verification
- Loan amount validation
- Dynamic interest rate calculation

### 3. Decision Outcomes
- APPROVED: Automatic approval
- DECLINED: Fails critical requirements
- CONDITIONAL_APPROVAL: Approved with conditions
- REFER_TO_UNDERWRITER: Requires manual review

### 4. Configurable Business Rules
- Minimum credit score
- Maximum LVR percentage
- Min/max loan amounts
- Feature toggles (auto-approval, credit-score-check)

## Technology Stack

- **Framework**: Quarkus 3.6.0
- **Language**: Java 17
- **Build Tool**: Gradle 8.5 (Multi-module)
- **API Specification**: OpenAPI 3.0
- **REST Framework**: JAX-RS
- **Testing**: JUnit 5, Mockito, REST Assured
- **Logging**: Structured JSON logging

## Configuration

### Application Port
- **Port**: 8086
- **Root Path**: /lending-decision-service

### Environment Variables
- `CONSUMER_API_KEYS`: API authentication keys
- `MIN_CREDIT_SCORE`: Minimum required credit score (default: 650)
- `MAX_LVR_PERCENTAGE`: Maximum LVR allowed (default: 80.0)
- `MIN_LOAN_AMOUNT`: Minimum loan amount (default: 50000.00)
- `MAX_LOAN_AMOUNT`: Maximum loan amount (default: 2000000.00)
- `FEATURE_AUTO_APPROVAL`: Enable auto-approval (default: true)
- `FEATURE_CREDIT_SCORE_CHECK`: Enable credit checks (default: true)

## Build & Run Commands

### Build
```bash
./gradlew build
```

### Run in Development Mode
```bash
./gradlew :app:quarkusDev
```

### Run Tests
```bash
./gradlew test
```

### Run Integration Tests
```bash
./gradlew integrationTest
```

## API Authentication

Uses X-API-KEY header:
```
X-API-KEY: LDATestApiKey123
```

## Sample Request

```json
{
  "applicationId": "APP-12345",
  "loanAmount": "500000.00",
  "loanPurpose": "HOME_PURCHASE",
  "loanTerm": 360,
  "applicant": {
    "crsNumber": "12345678",
    "firstName": "John",
    "lastName": "Smith",
    "income": "120000.00",
    "creditScore": 750,
    "employmentStatus": "FULL_TIME"
  },
  "property": {
    "address": "123 Queen Street, Auckland",
    "propertyType": "HOUSE",
    "estimatedValue": "800000.00",
    "purchasePrice": "750000.00"
  }
}
```

## Sample Response

```json
{
  "decisionId": "DEC-ABC12345",
  "applicationId": "APP-12345",
  "decisionStatus": "APPROVED",
  "decisionDate": "10-02-2026 14:30:00",
  "approvedAmount": "500000.00",
  "interestRate": "5.99",
  "loanToValueRatio": "62.50",
  "decisionReasons": [
    "Strong credit history",
    "Stable employment",
    "Acceptable LVR"
  ]
}
```

## Comparison with RCS

| Aspect | RCS | LDA |
|--------|-----|-----|
| Purpose | Rate rollover applications | Credit decisions |
| Port | 8085 | 8086 |
| Root Path | /ratechange-service | /lending-decision-service |
| Main Entity | Application | Decision |
| External Dependencies | Lending API, Host Adaptor, Opportunity Service | None (standalone) |
| Storage | External services | In-memory (demo) |

## Architecture Similarities with RCS

1. **Multi-module Gradle structure**
   - Separate API and implementation modules
   - OpenAPI code generation in API module

2. **Layered architecture**
   - API layer (generated from OpenAPI)
   - Service layer (business logic)
   - Implementation layer (REST endpoints)

3. **Common patterns**
   - CorrelationIdContext for request tracking
   - AuthenticationRequestFilter for API key validation
   - ExceptionHandler for centralized error handling
   - Configuration via ConfigMapping

4. **Testing approach**
   - Unit tests with QuarkusComponentTest
   - Integration tests with QuarkusTest and REST Assured
   - Mockito for mocking dependencies

## Next Steps for Production

1. **Replace in-memory storage** with database (PostgreSQL, MongoDB)
2. **Add external integrations**:
   - Credit bureau API for credit scores
   - Property valuation service
   - Customer data service
3. **Implement audit logging** for compliance
4. **Add message queue** for asynchronous processing
5. **Implement caching** for frequently accessed decisions
6. **Add metrics and monitoring** (Prometheus, Grafana)
7. **Set up CI/CD pipeline**
8. **Configure containerization** (Docker, Kubernetes)
9. **Implement data encryption** for sensitive information
10. **Add rate limiting** and throttling

## Files Created

1. **Configuration Files**
   - gradle.properties
   - settings.gradle
   - build.gradle (root)
   - app/build.gradle
   - lending-decision-api/build.gradle
   - gradle/wrapper/gradle-wrapper.properties
   - .gitignore

2. **Application Configuration**
   - src/main/resources/application.yaml

3. **OpenAPI Specification**
   - lending-decision-api/src/main/resources/openapi/lending-decision-api.yaml
   - src/main/resources/openapi/lending-decision-api.yaml

4. **Java Source Files**
   - LendingDecisionConfig.java
   - DecisionNotFoundException.java
   - ExceptionHandler.java
   - IneligibleApplicantException.java
   - InvalidDecisionRequestException.java
   - AuthenticationRequestFilter.java
   - DecisionsV1ServiceImpl.java
   - CreditDecisionService.java
   - CorrelationIdContext.java

5. **Test Files**
   - DecisionsV1ServiceImplTest.java
   - CreditDecisionServiceTest.java
   - DecisionsApiIntegrationTest.java

6. **Documentation**
   - README.md
   - PROJECT_SUMMARY.md (this file)

## License
Copyright 2025 Westpac New Zealand Limited. All Rights Reserved.
