# Lending Decision API (LDA)

This service provides credit decision functionality for lending applications, evaluating loan applications and providing automated credit decisions.

## Architecture

The Lending Decision API follows the same architectural patterns as the Rate Change Service (RCS):

- **Quarkus Framework**: Built on Quarkus for fast startup and low memory footprint
- **JAX-RS**: RESTful API implementation
- **OpenAPI First**: API-first design with OpenAPI 3.0 specification
- **Multi-module Gradle**: Separated into API and implementation modules

## Project Structure

```
lending-decision-api/
├── app/                                    # Main application module
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/
│   │   │   │   └── nz/co/westpac/lending/decision/
│   │   │   │       ├── config/            # Configuration classes
│   │   │   │       ├── exception/         # Custom exceptions and exception handler
│   │   │   │       ├── impl/              # Service implementations
│   │   │   │       ├── service/           # Business logic services
│   │   │   │       └── util/              # Utility classes
│   │   │   └── resources/
│   │   │       └── application.yaml       # Application configuration
│   │   └── test/
│   │       └── java/                      # Unit tests
│   └── build.gradle
├── lending-decision-api/                   # API module (generated from OpenAPI)
│   ├── src/main/resources/openapi/
│   │   └── lending-decision-api.yaml      # OpenAPI specification
│   └── build.gradle
├── build.gradle                            # Root build file
├── settings.gradle                         # Gradle settings
├── gradle.properties                       # Gradle properties
└── README.md
```

## Prerequisites

- Java 17 or higher
- Gradle 8.x or higher
- Docker (optional, for containerized deployment)

## Building the Project

```bash
# Build the entire project
./gradlew build

# Build without tests
./gradlew build -x test

# Run tests only
./gradlew test
```

## Running the Application

### Development Mode

```bash
./gradlew :app:quarkusDev
```

The application will start on `http://localhost:8086/lending-decision-service`

### Production Mode

```bash
# Build the application
./gradlew build

# Run the JAR
java -jar app/build/quarkus-app/quarkus-run.jar
```

## API Endpoints

### Create Credit Decision
```
POST /lending-decision-service/decisions/v1
```

Creates a new credit decision based on the provided application details.

**Request Body:**
```json
{
  "applicationId": "APP-12345",
  "loanAmount": "500000.00",
  "loanPurpose": "HOME_PURCHASE",
  "loanTerm": 360,
  "applicant": {
    "crsNumber": "12345678",
    "firstName": "John",
    "lastName": "Smith",
    "income": "120000.00",
    "creditScore": 750,
    "employmentStatus": "FULL_TIME"
  },
  "property": {
    "address": "123 Queen Street, Auckland",
    "propertyType": "HOUSE",
    "estimatedValue": "800000.00",
    "purchasePrice": "750000.00"
  }
}
```

**Response:**
```json
{
  "decisionId": "DEC-ABC12345",
  "applicationId": "APP-12345",
  "decisionStatus": "APPROVED",
  "decisionDate": "10-02-2026 14:30:00",
  "approvedAmount": "500000.00",
  "interestRate": "5.99",
  "loanToValueRatio": "62.50",
  "decisionReasons": [
    "Strong credit history",
    "Stable employment",
    "Acceptable LVR"
  ]
}
```

### Get Decision by ID
```
GET /lending-decision-service/decisions/v1/{decisionId}
```

Retrieves an existing credit decision by its ID.

## Configuration

Configuration is managed through `application.yaml`:

```yaml
lending-decision:
  consumer-api-keys: ${CONSUMER_API_KEYS:LDATestApiKey123}
  min-credit-score: ${MIN_CREDIT_SCORE:650}
  max-lvr-percentage: ${MAX_LVR_PERCENTAGE:80.0}
  min-loan-amount: ${MIN_LOAN_AMOUNT:50000.00}
  max-loan-amount: ${MAX_LOAN_AMOUNT:2000000.00}

feature:
  auto-approval: ${FEATURE_AUTO_APPROVAL:true}
  credit-score-check: ${FEATURE_CREDIT_SCORE_CHECK:true}
```

### Environment Variables

- `CONSUMER_API_KEYS`: Comma-separated list of valid API keys
- `MIN_CREDIT_SCORE`: Minimum credit score required (default: 650)
- `MAX_LVR_PERCENTAGE`: Maximum loan-to-value ratio percentage (default: 80.0)
- `MIN_LOAN_AMOUNT`: Minimum loan amount (default: 50000.00)
- `MAX_LOAN_AMOUNT`: Maximum loan amount (default: 2000000.00)
- `FEATURE_AUTO_APPROVAL`: Enable/disable automatic approvals (default: true)
- `FEATURE_CREDIT_SCORE_CHECK`: Enable/disable credit score checking (default: true)

## Authentication

The API uses API key authentication via the `X-API-KEY` header:

```bash
curl -X POST http://localhost:8086/lending-decision-service/decisions/v1 \
  -H "X-API-KEY: LDATestApiKey123" \
  -H "Content-Type: application/json" \
  -d '{...}'
```

## Decision Logic

The service implements automated credit decisioning based on:

1. **Credit Score**: Applicants must meet minimum credit score requirements
2. **Loan-to-Value Ratio (LVR)**: Calculated as (loan amount / property value) × 100
3. **Employment Status**: Employment verification and stability check
4. **Loan Amount**: Must be within configured min/max ranges
5. **Income**: Assessed against requested loan amount

### Decision Outcomes

- **APPROVED**: Application meets all criteria
- **DECLINED**: Application fails critical requirements
- **CONDITIONAL_APPROVAL**: Approved with conditions to be satisfied
- **REFER_TO_UNDERWRITER**: Requires manual review

## Health Checks

Quarkus provides built-in health checks:

```bash
# Liveness probe
curl http://localhost:8086/lending-decision-service/q/health/live

# Readiness probe
curl http://localhost:8086/lending-decision-service/q/health/ready
```

## Testing

```bash
# Run all tests
./gradlew test

# Run tests with coverage
./gradlew test jacocoTestReport

# Run specific test class
./gradlew test --tests "DecisionsV1ServiceImplTest"
```

## OpenAPI Documentation

The OpenAPI specification is available at:
- Development: `http://localhost:8086/lending-decision-service/q/openapi`
- Swagger UI: `http://localhost:8086/lending-decision-service/q/swagger-ui`

## Logging

The application uses structured JSON logging. Log configuration can be adjusted in `application.yaml`:

```yaml
quarkus:
  log:
    console:
      json:
        pretty-print: true
        date-format: "YYYY-MM-dd HH:mm:ss"
    level: INFO
```

## Comparison with RCS

This service follows the same patterns as the Rate Change Service:

| Aspect | RCS | LDA |
|--------|-----|-----|
| Framework | Quarkus 3.6.0 | Quarkus 3.6.0 |
| Port | 8085 | 8086 |
| Root Path | /ratechange-service | /lending-decision-service |
| Authentication | X-API-KEY | X-API-KEY |
| API Style | OpenAPI First | OpenAPI First |
| Build Tool | Gradle Multi-module | Gradle Multi-module |
| Architecture | Layered (API/Service/Impl) | Layered (API/Service/Impl) |

## License

Copyright 2025 Westpac New Zealand Limited. All Rights Reserved.
